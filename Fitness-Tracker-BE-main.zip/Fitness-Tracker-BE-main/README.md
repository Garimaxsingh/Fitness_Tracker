# Fitness-Tracker-BE
Backed for google fit api authentication

Add your own creds.json from GOOGLE DEVELOPERS CONSOLE and it will work.

Added appwrite functions to save data to appwrite.

# Front End Repository
Link: <a href="https://github.com/Sandeep228/Fitness-Tracker-"> FRONT END LINK </a> 
